let counter = 0;
export default function generateId() {
    return "generatedid" + counter++;
}